prompt --application/pages/page_00231
begin
--   Manifest
--     PAGE: 00231
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>231
,p_user_interface_id=>wwv_flow_api.id(6110350152565363)
,p_name=>'231-Registro o cambio persona autorizada a firma digital'
,p_alias=>'231-REGISTRO-O-CAMBIO-PERSONA-AUTORIZADA-A-FIRMA-DIGITAL'
,p_step_title=>'Registro o cambio persona autorizada a firma digital'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//Funcion para redireccionar a la pagina 135 y visualizar el archivo del apoderado',
'function Ir_Archivo_apoderado(pIdArchi, pIDApo,pIdContrib,pMostrar) {',
'    var vURL = ''f?p=&APP_ID.:135:&APP_SESSION.::NO:135:P135_ID_ARCHI_APODERA,P135_ID_APODERADO,P135_ID_CONTRIBUYENTE,P135_MOSTRAR_REGION:'' + pIdArchi + '','' + pIDApo+ '','' + pIdContrib+ '','' + pMostrar;',
'    window.open(vURL, "", "width=1000,height=800");',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20230706140758'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(43547474371307703)
,p_plug_name=>'Registro o cambio  de apoderados o persona autorizada firma digital'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(36578097729044955)
,p_name=>'Registro a cambio de Apoderados'
,p_parent_plug_id=>wwv_flow_api.id(43547474371307703)
,p_template=>wwv_flow_api.id(6025720942565417)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.ID_APODERADO,',
'       a.ID_CONTRIBUYENTE,',
'       a.ID_TIPO_APODERADO,',
'       a.NOMBRE_APODERADO,',
'       a.CEDULA_APODERADO,',
'       a.CORREO_APODERADO,',
'       a.ID_TIPO_IMPUESTO,',
'       a.INDICA_AUTORIZO,',
'       a.FECHA_INICIO_AUTORIZA,',
'       a.FECHA_FIN_AUTORIZA,',
'       a.CODIGO_ESTADO,',
'       PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR_CONTRIB (a.ID_CONTRIBUYENTE)CODIGO_TRIBUTARIO',
'      -- b.ID_ARCHI_APODERA,',
'      -- b.NOMBRE_ARCHIVO,',
'      -- sys.dbms_lob.getlength(b.ARCHIVO_APODERADO)VER,',
'       --sys.dbms_lob.getlength(b.ARCHIVO_APODERADO)DESCARGAR,',
'      -- b.MIMETYPE,',
'       --b.FEC_ACT',
'  from APODERADOS a--, ARCHIVOS_APODERADOS b',
'  where /*a.ID_APODERADO = b.ID_APODERADO',
'  and*/   a.INDICA_AUTORIZO in (''A'')',
'  and   a.CODIGO_ESTADO = ''P''',
'  and   PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR_CONTRIB (a.ID_CONTRIBUYENTE) = NVL(:P231_ID_CONTRIB,PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR_CONTRIB (a.ID_CONTRIBUYENTE))'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P231_ID_CONTRIB'
,p_query_row_template=>wwv_flow_api.id(6052064420565405)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36578411251044964)
,p_query_column_id=>1
,p_column_alias=>'ID_APODERADO'
,p_column_display_sequence=>3
,p_default_sort_column_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36578853062044968)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_column_heading=>'Contribuyente'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NOMBRE_ENTIDAD,ID_CONTRIBUYENTE',
'FROM MAESTRO_CONTRIBUYENTE'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36579204644044968)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPO_APODERADO'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36579674580044968)
,p_query_column_id=>4
,p_column_alias=>'NOMBRE_APODERADO'
,p_column_display_sequence=>5
,p_column_heading=>'Nombre Apoderado'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36580088125044968)
,p_query_column_id=>5
,p_column_alias=>'CEDULA_APODERADO'
,p_column_display_sequence=>6
,p_column_heading=>'Cedula Apoderado'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36580434748044968)
,p_query_column_id=>6
,p_column_alias=>'CORREO_APODERADO'
,p_column_display_sequence=>7
,p_column_heading=>'Correo Apoderado'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36580894330044969)
,p_query_column_id=>7
,p_column_alias=>'ID_TIPO_IMPUESTO'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36581235071044969)
,p_query_column_id=>8
,p_column_alias=>'INDICA_AUTORIZO'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36581629815044969)
,p_query_column_id=>9
,p_column_alias=>'FECHA_INICIO_AUTORIZA'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36582039393044969)
,p_query_column_id=>10
,p_column_alias=>'FECHA_FIN_AUTORIZA'
,p_column_display_sequence=>11
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36582453723044969)
,p_query_column_id=>11
,p_column_alias=>'CODIGO_ESTADO'
,p_column_display_sequence=>12
,p_column_heading=>'Estado'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(23282108311586061)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81338348984146143)
,p_query_column_id=>12
,p_column_alias=>'CODIGO_TRIBUTARIO'
,p_column_display_sequence=>1
,p_column_heading=>'Codigo Tributario'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36115697649785149)
,p_query_column_id=>13
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>15
,p_column_heading=>'Aprobar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P231_ID_CONTRIBUYENTE'',''#ID_CONTRIBUYENTE#'');javascript:$s(''P231_APODERADO'',''#NOMBRE_APODERADO#'');javascript:$s(''P231_ID_APO'',''#ID_APODERADO#'');javascript:openModal(''ID_APO''); $("#ID_APO").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36611441458747502)
,p_query_column_id=>14
,p_column_alias=>'DERIVED$02'
,p_column_display_sequence=>14
,p_column_heading=>'Rechazar'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:230:&SESSION.::&DEBUG.::P230_ID_CONTRIBUYENTE,P230_ID_TIPO_SOLICITUD,P230_PAGINA,P230_ID_APODERADO,P230_TIPO_CORREO:#ID_CONTRIBUYENTE#,9,231,#ID_APODERADO#,R'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(42250068408382103)
,p_query_column_id=>15
,p_column_alias=>'DERIVED$03'
,p_column_display_sequence=>13
,p_column_heading=>'Ver'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P231_ID_APODERADO'',''#ID_APODERADO#'');javascript:openModal(''ARCHI_APO''); $("#ARCHI_APO").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(36115108073785144)
,p_plug_name=>'Aprobar Solicitud'
,p_region_name=>'ID_APO'
,p_parent_plug_id=>wwv_flow_api.id(36578097729044955)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(6018269855565420)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(162637415268567822)
,p_name=>'Archivos Apoderados'
,p_region_name=>'ARCHI_APO'
,p_parent_plug_id=>wwv_flow_api.id(36578097729044955)
,p_template=>wwv_flow_api.id(6018269855565420)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_column=>1
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select b.ID_APODERADO,',
'       b.ID_ARCHI_APODERA,',
'       b.NOMBRE_ARCHIVO,',
'       sys.dbms_lob.getlength(b.ARCHIVO_APODERADO)VER,',
'       sys.dbms_lob.getlength(b.ARCHIVO_APODERADO)DESCARGAR,',
'       b.MIMETYPE',
'  from ARCHIVOS_APODERADOS b',
'  WHERE b.ID_APODERADO = :P231_ID_APODERADO',
'  '))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P231_ID_APODERADO'
,p_query_row_template=>wwv_flow_api.id(6052064420565405)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(80703587967069435)
,p_query_column_id=>1
,p_column_alias=>'ID_APODERADO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(80703988748069430)
,p_query_column_id=>2
,p_column_alias=>'ID_ARCHI_APODERA'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(80704384417069430)
,p_query_column_id=>3
,p_column_alias=>'NOMBRE_ARCHIVO'
,p_column_display_sequence=>3
,p_column_heading=>'Nombre Archivo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(80705584355069429)
,p_query_column_id=>4
,p_column_alias=>'VER'
,p_column_display_sequence=>6
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:ARCHI_APODERA_SOLICITUD:ARCHIVO_APODERADO:ID_ARCHI_APODERA::MIMETYPE:NOMBRE_ARCHIVO:::inline:Ver:'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(80704775232069429)
,p_query_column_id=>5
,p_column_alias=>'DESCARGAR'
,p_column_display_sequence=>4
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:ARCHIVOS_APODERADOS:ARCHIVO_APODERADO:ID_ARCHI_APODERA::MIMETYPE:NOMBRE_ARCHIVO:::attachment:Descargar:'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(80705162333069429)
,p_query_column_id=>6
,p_column_alias=>'MIMETYPE'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(80705928663069428)
,p_query_column_id=>7
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>7
,p_column_heading=>'Ver'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:Ir_Archivo_apoderado(''#ID_ARCHI_APODERA#'', ''#ID_APODERADO#'', ''&P201_ID_NUM_INSCRIPCION.'', ''AIR'');'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(43547586828307704)
,p_plug_name=>'Filtro'
,p_parent_plug_id=>wwv_flow_api.id(43547474371307703)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(81338404452146144)
,p_name=>'Registro o cambio Apoderado Firma Digital'
,p_parent_plug_id=>wwv_flow_api.id(43547474371307703)
,p_template=>wwv_flow_api.id(6025720942565417)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.ID_APODERADO,',
'       a.ID_CONTRIBUYENTE,',
'       a.ID_TIPO_APODERADO,',
'       a.NOMBRE_APODERADO,',
'       a.CEDULA_APODERADO,',
'       a.CORREO_APODERADO,',
'       a.ID_TIPO_IMPUESTO,',
'       a.INDICA_AUTORIZO,',
'       a.FECHA_INICIO_AUTORIZA,',
'       a.FECHA_FIN_AUTORIZA,',
'       a.CODIGO_ESTADO,',
'       PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR_CONTRIB (a.ID_CONTRIBUYENTE)CODIGO_TRIBUTARIO',
'      -- b.ID_ARCHI_APODERA,',
'      -- b.NOMBRE_ARCHIVO,',
'      -- sys.dbms_lob.getlength(b.ARCHIVO_APODERADO)VER,',
'       --sys.dbms_lob.getlength(b.ARCHIVO_APODERADO)DESCARGAR,',
'      -- b.MIMETYPE,',
'       --b.FEC_ACT',
'  from APODERADOS a--, ARCHIVOS_APODERADOS b',
'  where /*a.ID_APODERADO = b.ID_APODERADO',
'  and*/   a.INDICA_AUTORIZO in (''F'')',
'  and   a.CODIGO_ESTADO = ''P''',
'  and   PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR_CONTRIB (a.ID_CONTRIBUYENTE) = NVL(:P231_ID_CONTRIB,PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR_CONTRIB (a.ID_CONTRIBUYENTE))'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P231_ID_CONTRIB'
,p_query_row_template=>wwv_flow_api.id(6052064420565405)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81338623382146146)
,p_query_column_id=>1
,p_column_alias=>'ID_APODERADO'
,p_column_display_sequence=>2
,p_default_sort_column_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81338788076146147)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>4
,p_column_heading=>'Contribuyente'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NOMBRE_ENTIDAD,ID_CONTRIBUYENTE',
'FROM MAESTRO_CONTRIBUYENTE'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81338815372146148)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPO_APODERADO'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81338923388146149)
,p_query_column_id=>4
,p_column_alias=>'NOMBRE_APODERADO'
,p_column_display_sequence=>6
,p_column_heading=>'Nombre Apoderado'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81339086025146150)
,p_query_column_id=>5
,p_column_alias=>'CEDULA_APODERADO'
,p_column_display_sequence=>7
,p_column_heading=>'Cedula Apoderado'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81493158548069001)
,p_query_column_id=>6
,p_column_alias=>'CORREO_APODERADO'
,p_column_display_sequence=>8
,p_column_heading=>'Correo Apoderado'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81493284868069002)
,p_query_column_id=>7
,p_column_alias=>'ID_TIPO_IMPUESTO'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81493334488069003)
,p_query_column_id=>8
,p_column_alias=>'INDICA_AUTORIZO'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81493462085069004)
,p_query_column_id=>9
,p_column_alias=>'FECHA_INICIO_AUTORIZA'
,p_column_display_sequence=>11
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81493531333069005)
,p_query_column_id=>10
,p_column_alias=>'FECHA_FIN_AUTORIZA'
,p_column_display_sequence=>12
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81493672889069006)
,p_query_column_id=>11
,p_column_alias=>'CODIGO_ESTADO'
,p_column_display_sequence=>14
,p_column_heading=>'Estado'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(23282108311586061)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81493981235069009)
,p_query_column_id=>12
,p_column_alias=>'CODIGO_TRIBUTARIO'
,p_column_display_sequence=>3
,p_column_heading=>'Codigo Tributario'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81493878217069008)
,p_query_column_id=>13
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>17
,p_column_heading=>'Aprobar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P231_ID_CONTRIBUYENTE'',''#ID_CONTRIBUYENTE#'');javascript:$s(''P231_APODERADO'',''#NOMBRE_APODERADO#'');javascript:$s(''P231_ID_APO'',''#ID_APODERADO#'');javascript:openModal(''ID_APO''); $("#ID_APO").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81493756660069007)
,p_query_column_id=>14
,p_column_alias=>'DERIVED$02'
,p_column_display_sequence=>16
,p_column_heading=>'Rechazar'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:230:&SESSION.::&DEBUG.::P230_ID_CONTRIBUYENTE,P230_ID_TIPO_SOLICITUD,P230_PAGINA,P230_ID_APODERADO,P230_TIPO_CORREO:#ID_CONTRIBUYENTE#,10,231,#ID_APODERADO#,R'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81338580513146145)
,p_query_column_id=>15
,p_column_alias=>'DERIVED$03'
,p_column_display_sequence=>15
,p_column_heading=>'Ver'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P231_ID_APODERADO'',''#ID_APODERADO#'');javascript:openModal(''ARCHI_APO''); $("#ARCHI_APO").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(111927405471574206)
,p_query_column_id=>16
,p_column_alias=>'DERIVED$04'
,p_column_display_sequence=>13
,p_column_heading=>'Impuestos'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:242:&SESSION.::&DEBUG.::P242_ID_APODERADO:#ID_APODERADO#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(81494017990069010)
,p_name=>'Registro o cambio Apoderado Terceros'
,p_parent_plug_id=>wwv_flow_api.id(43547474371307703)
,p_template=>wwv_flow_api.id(6025720942565417)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.ID_APODERADO,',
'       a.ID_CONTRIBUYENTE,',
'       a.ID_TIPO_APODERADO,',
'       a.NOMBRE_APODERADO,',
'       a.CEDULA_APODERADO,',
'       a.CORREO_APODERADO,',
'       a.ID_TIPO_IMPUESTO,',
'       a.INDICA_AUTORIZO,',
'       a.FECHA_INICIO_AUTORIZA,',
'       a.FECHA_FIN_AUTORIZA,',
'       a.CODIGO_ESTADO,',
'       PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR_CONTRIB (a.ID_CONTRIBUYENTE)CODIGO_TRIBUTARIO',
'      -- b.ID_ARCHI_APODERA,',
'      -- b.NOMBRE_ARCHIVO,',
'      -- sys.dbms_lob.getlength(b.ARCHIVO_APODERADO)VER,',
'       --sys.dbms_lob.getlength(b.ARCHIVO_APODERADO)DESCARGAR,',
'      -- b.MIMETYPE,',
'       --b.FEC_ACT',
'  from APODERADOS a--, ARCHIVOS_APODERADOS b',
'  where /*a.ID_APODERADO = b.ID_APODERADO',
'  and*/   a.INDICA_AUTORIZO in (''T'')',
'  and   a.CODIGO_ESTADO = ''P''',
'  and   PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR_CONTRIB (a.ID_CONTRIBUYENTE) = NVL(:P231_ID_CONTRIB,PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR_CONTRIB (a.ID_CONTRIBUYENTE))'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P231_ID_CONTRIB'
,p_query_row_template=>wwv_flow_api.id(6052064420565405)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81494211151069012)
,p_query_column_id=>1
,p_column_alias=>'ID_APODERADO'
,p_column_display_sequence=>2
,p_default_sort_column_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81494396953069013)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>4
,p_column_heading=>'Contribuyente'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NOMBRE_ENTIDAD,ID_CONTRIBUYENTE',
'FROM MAESTRO_CONTRIBUYENTE'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81494412095069014)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPO_APODERADO'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81494591994069015)
,p_query_column_id=>4
,p_column_alias=>'NOMBRE_APODERADO'
,p_column_display_sequence=>6
,p_column_heading=>'Nombre Apoderado'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81494659160069016)
,p_query_column_id=>5
,p_column_alias=>'CEDULA_APODERADO'
,p_column_display_sequence=>7
,p_column_heading=>'Cedula Apoderado'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81494717561069017)
,p_query_column_id=>6
,p_column_alias=>'CORREO_APODERADO'
,p_column_display_sequence=>8
,p_column_heading=>'Correo Apoderado'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81494806905069018)
,p_query_column_id=>7
,p_column_alias=>'ID_TIPO_IMPUESTO'
,p_column_display_sequence=>9
,p_column_heading=>'Tipo Impuesto'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'NEVER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(12636490143437409)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81494955371069019)
,p_query_column_id=>8
,p_column_alias=>'INDICA_AUTORIZO'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81495080776069020)
,p_query_column_id=>9
,p_column_alias=>'FECHA_INICIO_AUTORIZA'
,p_column_display_sequence=>11
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81495117649069021)
,p_query_column_id=>10
,p_column_alias=>'FECHA_FIN_AUTORIZA'
,p_column_display_sequence=>12
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81495283240069022)
,p_query_column_id=>11
,p_column_alias=>'CODIGO_ESTADO'
,p_column_display_sequence=>13
,p_column_heading=>'Estado'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(23282108311586061)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81495587693069025)
,p_query_column_id=>12
,p_column_alias=>'CODIGO_TRIBUTARIO'
,p_column_display_sequence=>3
,p_column_heading=>'Codigo Tributario'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81495417299069024)
,p_query_column_id=>13
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>17
,p_column_heading=>'Aprobar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P231_ID_CONTRIBUYENTE'',''#ID_CONTRIBUYENTE#'');javascript:$s(''P231_APODERADO'',''#NOMBRE_APODERADO#'');javascript:$s(''P231_ID_APO'',''#ID_APODERADO#'');javascript:openModal(''ID_APO''); $("#ID_APO").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81495366965069023)
,p_query_column_id=>14
,p_column_alias=>'DERIVED$02'
,p_column_display_sequence=>16
,p_column_heading=>'Rechazar'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:230:&SESSION.::&DEBUG.::P230_ID_CONTRIBUYENTE,P230_ID_TIPO_SOLICITUD,P230_PAGINA,P230_ID_APODERADO,P230_TIPO_CORREO:#ID_CONTRIBUYENTE#,11,231,#ID_APODERADO#,R'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81494162263069011)
,p_query_column_id=>15
,p_column_alias=>'DERIVED$03'
,p_column_display_sequence=>15
,p_column_heading=>'Ver'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P231_ID_APODERADO'',''#ID_APODERADO#'');javascript:openModal(''ARCHI_APO''); $("#ARCHI_APO").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(111927569288574207)
,p_query_column_id=>16
,p_column_alias=>'DERIVED$04'
,p_column_display_sequence=>14
,p_column_heading=>'Impuestos'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:242:&SESSION.::&DEBUG.::P242_ID_APODERADO:#ID_APODERADO#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(200493463928272187)
,p_plug_name=>'Titulo'
,p_parent_plug_id=>wwv_flow_api.id(43547474371307703)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
'<center><h3>Registro o cambio  de apoderados</h3></center>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43547947286307708)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(43547586828307704)
,p_button_name=>'BTN_BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6087817714565383)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Buscar'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(36115539062785148)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(36115108073785144)
,p_button_name=>'BTN_APROBAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6087817714565383)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Aprobar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(36115286986785145)
,p_name=>'P231_ID_CONTRIBUYENTE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(36115108073785144)
,p_prompt=>'Contribuyente'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NOMBRE_ENTIDAD,ID_CONTRIBUYENTE',
'FROM MAESTRO_CONTRIBUYENTE'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6086783677565386)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(36115336331785146)
,p_name=>'P231_APODERADO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(36115108073785144)
,p_prompt=>'Apoderado'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6086783677565386)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(36611348501747501)
,p_name=>'P231_ID_APO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(36115108073785144)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43547602120307705)
,p_name=>'P231_ID_CONTRIB'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(43547586828307704)
,p_prompt=>unistr('C\00F3digo Tributario:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(79993347395253529)
,p_name=>'P231_ID_APODERADO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(162637415268567822)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(36115712033785150)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_APR_SOLICITUD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vTipoApoderado VARCHAR2(2);',
'vTipoSolicitud NUMBER;',
'',
'    CURSOR C_TIPO_APODERADO IS',
'    SELECT INDICA_AUTORIZO',
'    FROM APODERADOS',
'    WHERE ID_APODERADO = :P231_ID_APO;',
'BEGIN',
'UPDATE APODERADOS SET CODIGO_ESTADO = ''AC'',FECHA_INICIO_AUTORIZA = SYSDATE,USUARIO_SIT = :APP_USER WHERE ID_APODERADO = :P231_ID_APO AND ID_CONTRIBUYENTE = :P231_ID_CONTRIBUYENTE;',
'COMMIT;',
'',
'--Busca,os el tipo de apoderado para poder enviar la notificacion correcta.',
'    OPEN    C_TIPO_APODERADO;',
'    FETCH   C_TIPO_APODERADO INTO vTipoApoderado;',
'    CLOSE   C_TIPO_APODERADO;',
'    ',
'    IF vTipoApoderado = ''A'' THEN',
'        vTipoSolicitud := 9;',
'    ELSIF vTipoApoderado = ''F'' THEN',
'        vTipoSolicitud := 10;',
'    ELSIF vTipoApoderado = ''T'' THEN',
'        vTipoSolicitud := 11;',
'    END IF;',
'--Envio correo notificacion',
'PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_CONTRIBUYENTES (:P231_ID_CONTRIBUYENTE, NULL,vTipoSolicitud,''A'',''E'',0);',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(36115539062785148)
);
wwv_flow_api.component_end;
end;
/
