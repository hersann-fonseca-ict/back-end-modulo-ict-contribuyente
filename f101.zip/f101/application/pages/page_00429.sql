prompt --application/pages/page_00429
begin
--   Manifest
--     PAGE: 00429
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>429
,p_user_interface_id=>wwv_flow_api.id(6110350152565363)
,p_name=>'429-Bitacora Requisitos inscripcion regular'
,p_alias=>'429-BITACORA-REQUISITOS-INSCRIPCION-REGULAR'
,p_step_title=>unistr('Bit\00E1cora Requisitos inscripci\00F3n regular')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20221111094517'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(41397062508340198)
,p_plug_name=>'429-Bitacora Requisitos inscripcion regular'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6023806531565418)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_ARCHI_REQUI,',
'       ID_REQUISITOS_INS,',
'       ID_NUM_INSCRIPCION,',
'       NOMBRE_REQUISITO,',
'       MIMETYPE,',
'       FEC_ACT,',
'       FECHA,',
'       ID_TIPO_OPERACION,',
'       USUARIO',
'  from BITA_ARCHI_REQUI_INSCRIP',
'  where ID_NUM_INSCRIPCION = :P429_NUM_INSCRIPCION'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'429-Bitacora Requisitos inscripcion regular'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(41397167453340198)
,p_name=>'429-Bitacora Requisitos inscripcion regular'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'KIMBERLYN.SOLANO'
,p_internal_uid=>41397167453340198
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41397554488340198)
,p_db_column_name=>'ID_ARCHI_REQUI'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41397980879340199)
,p_db_column_name=>'ID_REQUISITOS_INS'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Requisito'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(20142085879981209)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41398327011340199)
,p_db_column_name=>'ID_NUM_INSCRIPCION'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Id Num Inscripcion'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41398781060340199)
,p_db_column_name=>'NOMBRE_REQUISITO'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Archivo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41399131830340199)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Mimetype'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41399527980340199)
,p_db_column_name=>'FEC_ACT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Fec Act'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41399926229340199)
,p_db_column_name=>'FECHA'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Fecha Mod.'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MM-YYYY HH:MIPM'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41400339257340200)
,p_db_column_name=>'ID_TIPO_OPERACION'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>unistr('Tipo Operaci\00F3n')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(31489783213927013)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41400770208340200)
,p_db_column_name=>'USUARIO'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(41411485261361545)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'414115'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>10
,p_report_columns=>'ID_ARCHI_REQUI:ID_REQUISITOS_INS:ID_NUM_INSCRIPCION:NOMBRE_REQUISITO:MIMETYPE:FEC_ACT:FECHA:ID_TIPO_OPERACION:USUARIO'
,p_sort_column_1=>'ID_ARCHI_REQUI'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'FECHA'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'ID_TIPO_OPERACION'
,p_sort_direction_3=>'DESC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(657547376425973696)
,p_plug_name=>'Bit requisitos inscripcion regular'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Bit\00E1cora requisitos inscripci\00F3n</h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(41437974537487726)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(657547376425973696)
,p_button_name=>'BTN_REGRESAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6087175290565385)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Btn Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:&P429_PAGINA.:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-double-left'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40843237706463630)
,p_name=>'P429_NUM_INSCRIPCION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(41397062508340198)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(41511908067725825)
,p_name=>'P429_PAGINA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(41397062508340198)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.component_end;
end;
/
