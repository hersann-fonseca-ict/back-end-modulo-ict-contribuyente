prompt --application/pages/page_00224
begin
--   Manifest
--     PAGE: 00224
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>224
,p_user_interface_id=>wwv_flow_api.id(6110350152565363)
,p_name=>'224-Formulario Grantias de cumplimiiento'
,p_alias=>'224-FORMULARIO-GRANTIAS-DE-CUMPLIMIIENTO'
,p_step_title=>'224-Formulario Grantias de cumplimiiento'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'JORGE.ROJAS'
,p_last_upd_yyyymmddhh24miss=>'20240321123746'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(98378778906033426)
,p_plug_name=>'Principal'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(35342305884278415)
,p_plug_name=>unistr('Garant\00EDas de Cumplimiento')
,p_parent_plug_id=>wwv_flow_api.id(98378778906033426)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'MAESTRO_CONTRIBUYENTE'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(139613522735402574)
,p_plug_name=>'Titulo'
,p_parent_plug_id=>wwv_flow_api.id(98378778906033426)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Garant\00EDas de Cumplimiento</h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(35401334548278449)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(35342305884278415)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6087817714565383)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P224_ID_CONTRIBUYENTE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(35400167312278448)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(35342305884278415)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6087817714565383)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:223:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(35401737361278449)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(35342305884278415)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6087817714565383)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Crear'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P224_ID_CONTRIBUYENTE'
,p_button_condition_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(35400920974278449)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(35342305884278415)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6087817714565383)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(35402001977278449)
,p_branch_name=>'Go To Page 223'
,p_branch_action=>'f?p=&APP_ID.:223:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35185815575676630)
,p_name=>'P224_CORREO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(35342305884278415)
,p_prompt=>'Correo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35185972319676631)
,p_name=>'P224_TELEFONO'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(35342305884278415)
,p_prompt=>unistr('Tel\00E9fono:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35186280598676634)
,p_name=>'P224_CEDULA_FISICA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(35342305884278415)
,p_item_source_plug_id=>wwv_flow_api.id(35342305884278415)
,p_prompt=>unistr('Cedula F\00EDsica:')
,p_source=>'CEDULA_FISICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_help_text=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35342794931278415)
,p_name=>'P224_ID_CONTRIBUYENTE'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(35342305884278415)
,p_item_source_plug_id=>wwv_flow_api.id(35342305884278415)
,p_item_default=>'SEQ_ID_CONTRIBUYENTE'
,p_item_default_type=>'SEQUENCE'
,p_source=>'ID_CONTRIBUYENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35343139666278415)
,p_name=>'P224_NOMBRE_ENTIDAD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(35342305884278415)
,p_item_source_plug_id=>wwv_flow_api.id(35342305884278415)
,p_prompt=>'Nombre:'
,p_source=>'NOMBRE_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_GARANT_NOM_PROV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT A.FIRMA_COMERCIAL NOMBRE_COMERCIAL, A.CEDULA',
'FROM PROVEEDORES@consulta_ictx A'))
,p_lov_display_null=>'YES'
,p_cSize=>60
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(6086844856565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35343501407278415)
,p_name=>'P224_ID_TIPO_IDENTIFICACION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(35342305884278415)
,p_item_source_plug_id=>wwv_flow_api.id(35342305884278415)
,p_prompt=>unistr('Tipo Identificaci\00F3n:')
,p_source=>'ID_TIPO_IDENTIFICACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPO_IDENTIFICACION'
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P224_NOMBRE_ENTIDAD'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(6086844856565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35343938110278416)
,p_name=>'P224_RAZON_SOCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(35342305884278415)
,p_item_source_plug_id=>wwv_flow_api.id(35342305884278415)
,p_prompt=>unistr('Raz\00F3n Social:')
,p_source=>'RAZON_SOCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>80
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35344786331278416)
,p_name=>'P224_CEDULA_JURIDICA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(35342305884278415)
,p_item_source_plug_id=>wwv_flow_api.id(35342305884278415)
,p_prompt=>unistr('Cedula Jur\00EDdica:')
,p_source=>'CEDULA_JURIDICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_help_text=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35345594652278417)
,p_name=>'P224_ID_TIPO_CONTRIBUYENTE'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(35342305884278415)
,p_item_source_plug_id=>wwv_flow_api.id(35342305884278415)
,p_item_default=>'13'
,p_prompt=>'Emisor de Pago:'
,p_source=>'ID_TIPO_CONTRIBUYENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select descripcion, id_tipo_contribuyente',
'from tipo_contribuyente',
'where id_Tipo_contribuyente = 13'))
,p_cHeight=>1
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35354376402278422)
,p_name=>'P224_OBSERVA_ADM_TRIBUTA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(35342305884278415)
,p_item_source_plug_id=>wwv_flow_api.id(35342305884278415)
,p_prompt=>'Observaciones:'
,p_source=>'OBSERVA_ADM_TRIBUTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>800
,p_cHeight=>4
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35361127093278426)
,p_name=>'P224_FECHA_INGRESO'
,p_source_data_type=>'DATE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(35342305884278415)
,p_item_source_plug_id=>wwv_flow_api.id(35342305884278415)
,p_prompt=>'Fecha:'
,p_format_mask=>'DD/MM/YYYY'
,p_source=>'FECHA_INGRESO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35367965578278430)
,p_name=>'P224_MONTO_MONEDA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(35342305884278415)
,p_item_source_plug_id=>wwv_flow_api.id(35342305884278415)
,p_prompt=>'Monto:'
,p_source=>'MONTO_MONEDA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38446575720669104)
,p_name=>'P224_VAL_MC'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(35342305884278415)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38446677269669105)
,p_name=>'P224_VALID_MC_MSJ'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(35342305884278415)
,p_item_default=>'El contribuyente ya se encuentra inscrito...'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="color:red;"'
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38647812393961118)
,p_name=>'P224_USUARIO_SIT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(35342305884278415)
,p_item_source_plug_id=>wwv_flow_api.id(35342305884278415)
,p_source=>'USUARIO_SIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(84936258841861621)
,p_name=>'P224_ID_DEUDOR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(35342305884278415)
,p_item_source_plug_id=>wwv_flow_api.id(35342305884278415)
,p_prompt=>unistr('C\00F3digo Tributario')
,p_source=>'ID_DEUDOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_column=>3
,p_display_when=>'P224_ID_CONTRIBUYENTE'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(84958798512006123)
,p_name=>'P224_TIPO_ID_GARANTIAS'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(35342305884278415)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(98377616391033415)
,p_name=>'P224_CODIGO_ESTADO'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(35342305884278415)
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_ESTADO'
,p_lov=>'.'||wwv_flow_api.id(15602871107195194)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(35187836520676650)
,p_validation_name=>'VAL_CED_JURIDICA'
,p_validation_sequence=>10
,p_validation=>'P224_CEDULA_JURIDICA'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_validation_condition=>'P224_CEDULA_JURIDICA'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(35344786331278416)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(35564412591405501)
,p_validation_name=>'VAL_CED_FISICA'
,p_validation_sequence=>20
,p_validation=>'P224_CEDULA_FISICA'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_validation_condition=>'P224_CEDULA_FISICA'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(35186280598676634)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(35564558387405502)
,p_validation_name=>'VAL_CORREO'
,p_validation_sequence=>30
,p_validation=>'P224_CORREO'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P224_CORREO'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(35185815575676630)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(38446311043669102)
,p_name=>'DAC_VAL_EXISTE_CEDJ'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P224_CEDULA_JURIDICA'
,p_condition_element=>'P224_CEDULA_JURIDICA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(38446452894669103)
,p_event_id=>wwv_flow_api.id(38446311043669102)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vExiste VARCHAR2(1);',
'BEGIN',
':P224_VAL_MC:= PKG_MAESTRO_CONTRIBUYENTE.VALIDA_EXISTE_MC (:P224_CEDULA_JURIDICA);',
'END;'))
,p_attribute_02=>'P224_CEDULA_JURIDICA'
,p_attribute_03=>'P224_VAL_MC'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(38447201743669111)
,p_name=>'DAC_VAL_EXISTE_CEDF'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P224_CEDULA_FISICA'
,p_condition_element=>'P224_CEDULA_FISICA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(38447369781669112)
,p_event_id=>wwv_flow_api.id(38447201743669111)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vExiste VARCHAR2(1);',
'BEGIN',
':P224_VAL_MC:= PKG_MAESTRO_CONTRIBUYENTE.VALIDA_EXISTE_MC (:P224_CEDULA_FISICA);',
'END;'))
,p_attribute_02=>'P224_CEDULA_FISICA'
,p_attribute_03=>'P224_VAL_MC'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(38446728905669106)
,p_name=>'DAC_MUESTRA_MSJ'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P224_VAL_MC'
,p_condition_element=>'P224_VAL_MC'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(38446818999669107)
,p_event_id=>wwv_flow_api.id(38446728905669106)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P224_VALID_MC_MSJ'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(38447020859669109)
,p_event_id=>wwv_flow_api.id(38446728905669106)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P224_VALID_MC_MSJ'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(38446997732669108)
,p_event_id=>wwv_flow_api.id(38446728905669106)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(35401737361278449)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(38447117508669110)
,p_event_id=>wwv_flow_api.id(38446728905669106)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(35401737361278449)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(84936356286861622)
,p_name=>'DAC_UPPER_ENTIDAD'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P224_NOMBRE_ENTIDAD'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(84936496747861623)
,p_event_id=>wwv_flow_api.id(84936356286861622)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P224_NOMBRE_ENTIDAD").val($("#P224_NOMBRE_ENTIDAD").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(84936540471861624)
,p_name=>'DAC_UPPER_RAZON'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P224_RAZON_SOCIAL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(84936669082861625)
,p_event_id=>wwv_flow_api.id(84936540471861624)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P224_RAZON_SOCIAL").val($("#P224_RAZON_SOCIAL").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(84936771372861626)
,p_name=>'DAC_UPPER_OBSERV'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P224_OBSERVA_ADM_TRIBUTA'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(84936864127861627)
,p_event_id=>wwv_flow_api.id(84936771372861626)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P224_OBSERVA_ADM_TRIBUTA").val($("#P224_OBSERVA_ADM_TRIBUTA").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(84958590674006121)
,p_name=>'DAC_TRAE_DATOS_PROVE'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P224_NOMBRE_ENTIDAD'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(84958675080006122)
,p_event_id=>wwv_flow_api.id(84958590674006121)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Declare',
' v_cedula varchar2(30);',
' v_tipo_personeria varchar2(1);',
' v_email varchar2(100);',
' v_telefono1 varchar2(20);',
' v_codigo number;',
' v_firma_C varchar2(200);',
' ',
'CURSOR C_TRAE_DATOS IS',
'    SELECT replace(cedula2,''-'','''') cedula,TIPO_PERSONERIA, EMAIL, TELEFONO1, FIRMA_COMERCIAL',
'    FROM PROVEEDORES@consulta_ictx',
'    WHERE CEDULA = :P224_NOMBRE_ENTIDAD; ',
'',
'Begin',
'',
'  OPEN  C_TRAE_DATOS;',
'  FETCH C_TRAE_DATOS INTO v_cedula,v_tipo_personeria,v_email,v_telefono1,v_firma_C;',
'  CLOSE C_TRAE_DATOS;',
'',
'  --:P224_TIPO_ID_GARANTIAS := v_tipo_personeria;',
' --:P224_ID_TIPO_IDENTIFICACION := :P224_TIPO_ID_GARANTIAS;',
'',
'  if v_tipo_personeria = ''J''',
'  then',
'     :P224_ID_TIPO_IDENTIFICACION := 1; ',
'     :P224_CEDULA_JURIDICA := v_cedula;',
'    ELSIF v_tipo_personeria = ''F'' then',
'    :P224_ID_TIPO_IDENTIFICACION := 2; ',
'    :P224_CEDULA_FISICA := v_cedula;',
'  ELSIF v_tipo_personeria = ''E'' then',
'    :P224_ID_TIPO_IDENTIFICACION := 6; ',
'    :P224_CEDULA_FISICA := v_cedula;',
'  end if;',
'     :P224_CORREO := v_email;',
'     :P224_TELEFONO :=  v_telefono1; ',
'     :P224_NOMBRE_ENTIDAD := v_firma_C;',
'End;',
'',
''))
,p_attribute_02=>'P224_NOMBRE_ENTIDAD'
,p_attribute_03=>'P224_CEDULA_JURIDICA,P224_CEDULA_FISICA,P224_CORREO,P224_TELEFONO,P224_ID_TIPO_IDENTIFICACION'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(84958929541006125)
,p_name=>'DAC_TIPO_CEDULAS'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P224_ID_TIPO_IDENTIFICACION'
,p_condition_element=>'P224_ID_TIPO_IDENTIFICACION'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(84959025408006126)
,p_event_id=>wwv_flow_api.id(84958929541006125)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P224_CEDULA_JURIDICA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(84959225025006128)
,p_event_id=>wwv_flow_api.id(84958929541006125)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P224_CEDULA_FISICA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(27638878826385607)
,p_event_id=>wwv_flow_api.id(84958929541006125)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P224_CEDULA_FISICA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(27638956481385608)
,p_event_id=>wwv_flow_api.id(84958929541006125)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P224_CEDULA_JURIDICA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(84959123776006127)
,p_event_id=>wwv_flow_api.id(84958929541006125)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P224_CEDULA_FISICA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(84959395979006129)
,p_event_id=>wwv_flow_api.id(84958929541006125)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P224_CEDULA_JURIDICA'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(35402974303278450)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(35342305884278415)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form 224-Formulario Grantias de cumplimiiento'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(35186959732676641)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ACT_GARANTIA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vTelefono NUMBER;',
'vCorreos VARCHAR2(40);',
'vEstadoContrib VARCHAR2(2);',
'vRazonSocial Varchar2(80);',
'vMensaje_Retorno VARCHAR2(200);',
'vRetorno BOOLEAN;',
'vCedulaJuridica VARCHAR2(20);',
'vCedulaFisica VARCHAR2(20);',
'',
'    CURSOR C_TELEFONOS IS',
'    SELECT TELEFONO',
'    FROM   TELEFONO_X_MAESTRO_CONTRIBU',
'    WHERE  ID_CONTRIBUYENTE = :P224_ID_CONTRIBUYENTE;',
'    ',
'    CURSOR C_CORREOS IS',
'    SELECT CORREO_NOTIFICA',
'    FROM CORREO_NOTIFICACIONES',
'    WHERE ID_CONTRIBUYENTE = :P224_ID_CONTRIBUYENTE;',
'',
'    CURSOR C_RAZON IS',
'    SELECT RAZON_SOCIAL, CEDULA_JURIDICA, CEDULA_FISICA ',
'    FROM MAESTRO_CONTRIBUYENTE',
'    WHERE ID_CONTRIBUYENTE = :P224_ID_CONTRIBUYENTE;',
'',
'BEGIN',
'    OPEN  C_TELEFONOS;',
'    FETCH C_TELEFONOS INTO vTelefono;',
'    CLOSE C_TELEFONOS;',
'    ',
'    OPEN  C_CORREOS;',
'    FETCH C_CORREOS INTO vCorreos;',
'    CLOSE C_CORREOS;',
'    ',
'    OPEN  C_RAZON;',
'    FETCH C_RAZON INTO vRazonSocial, vCedulaJuridica, vCedulaFisica;',
'    CLOSE C_RAZON;',
'    ',
'    vEstadoContrib := PKG_MAESTRO_CONTRIBUYENTE.F_RETORNA_ESTADO_CONTRIB(:P224_ID_DEUDOR);',
'    ',
'    IF vTelefono <> :P224_TELEFONO THEN',
'        UPDATE TELEFONO_X_MAESTRO_CONTRIBU SET TELEFONO = :P224_TELEFONO,USUARIO_SIT = :APP_USER WHERE ID_CONTRIBUYENTE = :P224_ID_CONTRIBUYENTE;',
'    elsif vTelefono is null then',
'         ',
'         PKG_MAESTRO_CONTRIBUYENTE.P_INSERTA_TELEFONOS_NC (:P224_ID_CONTRIBUYENTE,',
'                                                           :P224_TELEFONO,',
'                                                            1,',
'                                                           :APP_USER,',
'                                                            vMensaje_Retorno,',
'                                                            vRetorno);',
'',
'       IF NOT vRetorno THEN',
'          ROLLBACK;',
'       else',
'          COMMIT;',
'       end if;  ',
'    end if;',
'',
'    IF vCorreos <> :P224_CORREO THEN',
'        UPDATE CORREO_NOTIFICACIONES SET CORREO_NOTIFICA = :P224_CORREO,USUARIO_SIT = :APP_USER WHERE ID_CONTRIBUYENTE = :P224_ID_CONTRIBUYENTE;',
'    elsif vCorreos is null then',
'   ',
'       PKG_MAESTRO_CONTRIBUYENTE.P_INSERTA_CORREOS_NC (:P224_ID_CONTRIBUYENTE,',
'                                                       :P224_CORREO,',
'                                                       :APP_USER,',
'                                                        vMensaje_Retorno,',
'                                                        vRetorno);',
'       IF NOT vRetorno THEN',
'              ROLLBACK;',
'           else',
'              COMMIT;',
'           end if;                                                   ',
'    end if;',
'   ',
'      ',
'    IF vEstadoContrib <> :P224_CODIGO_ESTADO THEN',
'         UPDATE MAESTRO_CONTRIBUYENTE SET CODIGO_ESTADO = :P224_CODIGO_ESTADO, USUARIO_SIT = :APP_USER WHERE ID_CONTRIBUYENTE = :P224_ID_CONTRIBUYENTE;',
'         COMMIT;',
'    END IF;',
'    ',
'    IF vRazonSocial <> :P224_RAZON_SOCIAL THEN',
'         UPDATE MAESTRO_CONTRIBUYENTE SET RAZON_SOCIAL = :P224_RAZON_SOCIAL, USUARIO_SIT = :APP_USER WHERE ID_CONTRIBUYENTE = :P224_ID_CONTRIBUYENTE;',
'         COMMIT;',
'    END IF;',
' ',
'   IF vCedulaJuridica <> :P224_CEDULA_JURIDICA OR vCedulaJuridica is null THEN',
'        UPDATE MAESTRO_CONTRIBUYENTE SET CEDULA_JURIDICA = :P224_CEDULA_JURIDICA,',
'                                         CEDULA_FISICA = NULL, ',
'                                         ID_TIPO_IDENTIFICACION = :P224_ID_TIPO_IDENTIFICACION, ',
'                                         USUARIO_SIT = :APP_USER ',
'        WHERE ID_CONTRIBUYENTE = :P224_ID_CONTRIBUYENTE;',
'        COMMIT;',
'   END IF; ',
' ',
'   IF vCedulaFisica <> :P224_CEDULA_FISICA OR vCedulaFisica is null THEN',
'        UPDATE MAESTRO_CONTRIBUYENTE SET CEDULA_FISICA = :P224_CEDULA_FISICA,',
'                                         CEDULA_JURIDICA = NULL,',
'                                         ID_TIPO_IDENTIFICACION = :P224_ID_TIPO_IDENTIFICACION, ',
'                                         USUARIO_SIT = :APP_USER ',
'        WHERE ID_CONTRIBUYENTE = :P224_ID_CONTRIBUYENTE;',
'        COMMIT;',
'   END IF; ',
' ',
'    ',
'    ',
'    ',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(35401334548278449)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10116717006669136)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ACT/INAC_CONTRIB'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vMensaje_Retorno VARCHAR2(200);',
'vRetorno boolean;',
'vCedula VARCHAR2(20);',
'BEGIN',
'IF :P224_CODIGO_ESTADO <> ''AC'' THEN',
'     --Se inserta el periodo de inactivacion ',
'    PKG_MAESTRO_CONTRIBUYENTE.INSERTA_PERIODO_INACTIVACION (:P224_ID_CONTRIBUYENTE,:APP_USER,''I'');',
'    --Inactivar en maestro_deudores',
'    UPDATE MAESTRO_DEUDORES@CONSULTA_ICTX SET CODIGO_ESTADO = ''AI'' WHERE ID_DEUDOR = :P224_ID_DEUDOR;',
'END IF;',
'IF  :P224_CODIGO_ESTADO <> ''IA'' THEN',
'    --Se inserta el periodo de inactivacion ',
'    PKG_MAESTRO_CONTRIBUYENTE.INSERTA_PERIODO_INACTIVACION (:P224_ID_CONTRIBUYENTE,:APP_USER,''A'');',
'    --Activar en maestro_deudores',
'    UPDATE MAESTRO_DEUDORES@CONSULTA_ICTX SET CODIGO_ESTADO = ''AC'' WHERE ID_DEUDOR = :P224_ID_DEUDOR;',
'',
'END IF;',
'    COMMIT;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(35401334548278449)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(35402560513278450)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(35342305884278415)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form 224-Formulario Grantias de cumplimiiento'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(35187008060676642)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vTelefono NUMBER;',
'vCorreos VARCHAR2(40);',
'vNomEntidad VARCHAR2(100);',
'',
'    CURSOR C_TELEFONOS IS',
'    SELECT TELEFONO',
'    FROM   TELEFONO_X_MAESTRO_CONTRIBU',
'    WHERE  ID_CONTRIBUYENTE = :P224_ID_CONTRIBUYENTE',
'    AND ID_TELEFONO IN (SELECT MAX(ID_TELEFONO) ',
'                        FROM TELEFONO_X_MAESTRO_CONTRIBU ',
'                        WHERE ID_CONTRIBUYENTE = :P224_ID_CONTRIBUYENTE);   ',
'    ',
'    CURSOR C_CORREOS IS',
'    SELECT CORREO_NOTIFICA',
'    FROM CORREO_NOTIFICACIONES',
'    WHERE ID_CONTRIBUYENTE = :P224_ID_CONTRIBUYENTE',
'    AND ID_CORREO_NOTIFICA IN (SELECT MAX(ID_CORREO_NOTIFICA) ',
'                              FROM CORREO_NOTIFICACIONES',
'                              WHERE ID_CONTRIBUYENTE = :P224_ID_CONTRIBUYENTE AND',
'                                    CODIGO_ESTADO = ''AC'');   ',
'  ',
'BEGIN',
'    OPEN  C_TELEFONOS;',
'    FETCH C_TELEFONOS INTO vTelefono;',
'    CLOSE C_TELEFONOS;',
'    ',
'    OPEN  C_CORREOS;',
'    FETCH C_CORREOS INTO vCorreos;',
'    CLOSE C_CORREOS;',
'        ',
'    IF :P224_ID_CONTRIBUYENTE IS NOT NULL THEN',
'     vNomEntidad := PKG_MAESTRO_CONTRIBUYENTE.F_RETORNA_NOM_CONTRI_ID_CONTRI(:P224_ID_CONTRIBUYENTE); ',
'   -- :P224_NOMBRE_ENTIDAD := vNomEntidad;',
'    :P224_TELEFONO := vTelefono;',
'    :P224_CORREO   := vCorreos;',
'    :P224_CODIGO_ESTADO := PKG_MAESTRO_CONTRIBUYENTE.F_RETORNA_ESTADO_CONTRIB(:P224_ID_DEUDOR);',
'   else ',
'    :P224_CEDULA_JURIDICA := null;',
'    :P224_CEDULA_FISICA := null;',
'   END IF;',
'    :P224_USUARIO_SIT := :APP_USER;',
'END;',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
''))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(35186184011676633)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERT_GARANTIA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vMensaje_Retorno VARCHAR2(200);',
'vRetorno BOOLEAN;',
'vContribuyente NUMBER;',
'vFechaIngreso DATE;',
'vNomProveedor VARCHAR2(100);',
'',
'--vCed_Fisica VARCHAR2(20);',
'--vCed_Juridica VARCHAR2(20);',
' ',
'/*cursor cur_trae_nom_prove is ',
'SELECT FIRMA_COMERCIAL NOMBRE_COMERCIAL ',
'FROM PROVEEDORES@consulta_ictx ',
'WHERE CEDULA = :P224_NOMBRE_ENTIDAD;*/',
'',
'',
'BEGIN',
'',
'   /* open cur_trae_nom_prove; ',
'    fetch cur_trae_nom_prove into vNomProveedor; ',
'    close cur_trae_nom_prove;*/',
'',
'--raise_application_error(-20000,  vNomProveedor);',
'',
'vFechaIngreso := TO_DATE(:P224_FECHA_INGRESO,''DD/MM/YYYY'');',
'PKG_MAESTRO_CONTRIBUYENTE.P_INSCRIPCION_NC_GARANTIAS (vContribuyente,',
'                                  :P224_NOMBRE_ENTIDAD,',
'                                  :P224_RAZON_SOCIAL,',
'                                  :P224_ID_TIPO_IDENTIFICACION,',
'                                  :P224_CEDULA_JURIDICA,',
'                                  :P224_CEDULA_FISICA,',
'                                  :P224_TELEFONO,',
'                                  :P224_CORREO,',
'                                  vFechaIngreso,',
'                                  :P224_MONTO_MONEDA,',
'                                  13,',
'                                  :P224_OBSERVA_ADM_TRIBUTA,',
'                                  :APP_USER,',
'                                  vMensaje_Retorno,',
'                                  vRetorno);',
'                                  ',
' IF NOT vRetorno THEN',
'    ROLLBACK;',
' else',
'    COMMIT;',
'',
'/*   IF :P224_ID_TIPO_IDENTIFICACION = 1 THEN',
'        vCed_Juridica:= :P103_CEDULA;',
'    ELSE',
'        vCed_Fisica := :P103_CEDULA;',
'    END IF;',
'      ',
' ',
'    --Actualiza Nombre Entidad',
'    UPDATE MAESTRO_CONTRIBUYENTE SET NOMBRE_ENTIDAD = vNomProveedor WHERE ID_CONTRIBUYENTE = :P224_ID_CONTRIBUYENTE;*/',
'    ',
' END IF;',
'END;',
'',
'',
''))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(35401737361278449)
);
wwv_flow_api.component_end;
end;
/
