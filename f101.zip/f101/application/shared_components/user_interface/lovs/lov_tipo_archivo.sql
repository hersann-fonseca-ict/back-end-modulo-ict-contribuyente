prompt --application/shared_components/user_interface/lovs/lov_tipo_archivo
begin
--   Manifest
--     LOV_TIPO_ARCHIVO
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(13712686236172630)
,p_lov_name=>'LOV_TIPO_ARCHIVO'
,p_lov_query=>'.'||wwv_flow_api.id(13712686236172630)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13713092868172628)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Manual usuario externo'
,p_lov_return_value=>'ME'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13713414609172628)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Formato'
,p_lov_return_value=>'F'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13713874214172626)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Pol\00EDtica')
,p_lov_return_value=>'P'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13714233549172626)
,p_lov_disp_sequence=>13
,p_lov_disp_value=>'Manual usuario interno'
,p_lov_return_value=>'MI'
);
wwv_flow_api.component_end;
end;
/
