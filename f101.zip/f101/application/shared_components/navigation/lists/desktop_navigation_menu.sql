prompt --application/shared_components/navigation/lists/desktop_navigation_menu
begin
--   Manifest
--     LIST: Desktop Navigation Menu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(5972268189565468)
,p_name=>'Desktop Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6120231872565309)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Inicio'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6543802970987085)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Par\00E1metros')
,p_list_item_icon=>'fa-save'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(13853338127932931)
,p_list_item_display_sequence=>21
,p_list_item_link_text=>unistr('T\00E9cnico')
,p_list_item_disp_cond_type=>'NEVER'
,p_parent_list_item_id=>wwv_flow_api.id(6543802970987085)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(15585974451235885)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Sistemas'
,p_list_item_link_target=>'f?p=&APP_ID.:202:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(13853338127932931)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'202'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(23189187197316303)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Tipo Movimientos SIT'
,p_list_item_link_target=>'f?p=&APP_ID.:122:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(13853338127932931)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'122,123'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(42792921407848046)
,p_list_item_display_sequence=>642
,p_list_item_link_text=>'Tipo modulo'
,p_list_item_link_target=>'f?p=&APP_ID.:138:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(13853338127932931)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'138,139'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(42760030109711304)
,p_list_item_display_sequence=>651
,p_list_item_link_text=>'Roles internos SIT'
,p_list_item_link_target=>'f?p=&APP_ID.:136:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(13853338127932931)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'136,137'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6552416046806500)
,p_list_item_display_sequence=>22
,p_list_item_link_text=>'Tipo ventas'
,p_list_item_link_target=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(6543802970987085)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(11675963559015949)
,p_list_item_display_sequence=>23
,p_list_item_link_text=>unistr('Tipo tel\00E9fono')
,p_list_item_link_target=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(6543802970987085)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6544102125983580)
,p_list_item_display_sequence=>24
,p_list_item_link_text=>'Tipo requisitos'
,p_list_item_link_target=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(6543802970987085)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6553013671796449)
,p_list_item_display_sequence=>25
,p_list_item_link_text=>'Tipo modalidad'
,p_list_item_link_target=>'f?p=&APP_ID.:104:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(6543802970987085)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6552730209803997)
,p_list_item_display_sequence=>26
,p_list_item_link_text=>'Tipo apoderado'
,p_list_item_link_target=>'f?p=&APP_ID.:106:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(6543802970987085)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(11674440104037058)
,p_list_item_display_sequence=>27
,p_list_item_link_text=>unistr('Tipo identificaci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(6543802970987085)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6571388693473504)
,p_list_item_display_sequence=>29
,p_list_item_link_text=>'Tipo puesto fronterizo'
,p_list_item_link_target=>'f?p=&APP_ID.:108:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(6543802970987085)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(13956753280824747)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Tipo Solicitud'
,p_list_item_link_target=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(6543802970987085)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'110,111'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(22973707475563255)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Tipo Contribuyente'
,p_list_item_link_target=>'f?p=&APP_ID.:118:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(6543802970987085)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'118,119'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(31258555049604616)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Tipo Ente'
,p_list_item_link_target=>'f?p=&APP_ID.:125:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(6543802970987085)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'125,126'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32108549672759089)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Tipo Local'
,p_list_item_link_target=>'f?p=&APP_ID.:127:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(6543802970987085)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'127,128'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33679545086129800)
,p_list_item_display_sequence=>230
,p_list_item_link_text=>'Tipo Empleado'
,p_list_item_link_target=>'f?p=&APP_ID.:129:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(6543802970987085)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'129,130'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(36184392307041054)
,p_list_item_display_sequence=>411
,p_list_item_link_text=>'Correos'
,p_list_item_link_target=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(6543802970987085)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'131,132'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(36257209699103053)
,p_list_item_display_sequence=>421
,p_list_item_link_text=>'Encargado Correo'
,p_list_item_link_target=>'f?p=&APP_ID.:133:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(6543802970987085)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'133,134'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(43057058844404191)
,p_list_item_display_sequence=>661
,p_list_item_link_text=>'Tipo Recomendacion'
,p_list_item_link_target=>'f?p=&APP_ID.:140:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(6543802970987085)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'140,141'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(98181824512269113)
,p_list_item_display_sequence=>721
,p_list_item_link_text=>'Tipo Noticia'
,p_list_item_link_target=>'f?p=&APP_ID.:145:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(6543802970987085)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'145,146'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(98326562542238417)
,p_list_item_display_sequence=>741
,p_list_item_link_text=>'Noticias Sit'
,p_list_item_link_target=>'f?p=&APP_ID.:147:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(6543802970987085)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'147,148'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32537178489739949)
,p_list_item_display_sequence=>35
,p_list_item_link_text=>'Procesos'
,p_list_item_link_target=>'#'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(35613229212135950)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Hoteles'
,p_list_item_link_target=>'f?p=&APP_ID.:227:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32537178489739949)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'227,228'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(12520875268464333)
,p_list_item_display_sequence=>31
,p_list_item_link_text=>unistr('Inscripci\00F3n Regular')
,p_parent_list_item_id=>wwv_flow_api.id(32537178489739949)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(12560596147398298)
,p_list_item_display_sequence=>32
,p_list_item_link_text=>unistr('Inscripci\00F3n Regular Pendiente')
,p_list_item_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(12520875268464333)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'200,201'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(13397968379789163)
,p_list_item_display_sequence=>34
,p_list_item_link_text=>unistr('Solicitud des-Inscripci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:203:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(12520875268464333)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32538034132769145)
,p_list_item_display_sequence=>36
,p_list_item_link_text=>unistr('Actualizaci\00F3n Contribuyente')
,p_list_item_link_target=>'f?p=&APP_ID.:207:&SESSION.::&DEBUG.:207:P207_TIPO_INSCRIPCION:IR:'
,p_parent_list_item_id=>wwv_flow_api.id(12520875268464333)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27918284862993812)
,p_list_item_display_sequence=>33
,p_list_item_link_text=>unistr('Inscripci\00F3n Vuelos ch\00E1rter')
,p_parent_list_item_id=>wwv_flow_api.id(32537178489739949)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'205,206'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(35292501983674071)
,p_list_item_display_sequence=>390
,p_list_item_link_text=>'Inscripciones Pendientes'
,p_list_item_link_target=>'f?p=&APP_ID.:205:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(27918284862993812)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(38073168929104272)
,p_list_item_display_sequence=>441
,p_list_item_link_text=>unistr('Actualizaci\00F3n Contribuyente')
,p_list_item_link_target=>'f?p=&APP_ID.:207:&SESSION.::&DEBUG.:207:P207_TIPO_INSCRIPCION:IVC:'
,p_parent_list_item_id=>wwv_flow_api.id(27918284862993812)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32538315258773382)
,p_list_item_display_sequence=>190
,p_list_item_link_text=>'Registro No Contribuyente'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32537178489739949)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33458585613096436)
,p_list_item_display_sequence=>220
,p_list_item_link_text=>'Ferias Internacionales'
,p_list_item_link_target=>'f?p=&APP_ID.:209:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32538315258773382)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'209,210'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33773293581123644)
,p_list_item_display_sequence=>240
,p_list_item_link_text=>'Funcionarios / Ex-Funcionarios'
,p_list_item_link_target=>'f?p=&APP_ID.:211:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32538315258773382)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'211,212'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33925757753562889)
,p_list_item_display_sequence=>250
,p_list_item_link_text=>'Concesiones Golfo de Papagayo'
,p_list_item_link_target=>'f?p=&APP_ID.:213:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32538315258773382)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'213,214'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(34022745729866394)
,p_list_item_display_sequence=>270
,p_list_item_link_text=>'Alquiler-Propiedades ICT (Locales)'
,p_list_item_link_target=>'f?p=&APP_ID.:215:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32538315258773382)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'215,216'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(35437631544284769)
,p_list_item_display_sequence=>310
,p_list_item_link_text=>unistr('Garant\00EDas de Cumplimiento')
,p_list_item_link_target=>'f?p=&APP_ID.:223:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32538315258773382)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(35340600900245158)
,p_list_item_display_sequence=>400
,p_list_item_link_text=>unistr('Garant\00EDas de Participaci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:225:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32538315258773382)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(34379388414548617)
,p_list_item_display_sequence=>401
,p_list_item_link_text=>'Otros Entes externos'
,p_list_item_link_target=>'f?p=&APP_ID.:217:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32538315258773382)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'217,218'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(35044128767260234)
,p_list_item_display_sequence=>360
,p_list_item_link_text=>'Agencias de Viajes No Recaudaras de impuestos'
,p_parent_list_item_id=>wwv_flow_api.id(32537178489739949)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(35289435185600171)
,p_list_item_display_sequence=>370
,p_list_item_link_text=>'Revisar Registro Agencia de Viajes'
,p_list_item_link_target=>'f?p=&APP_ID.:219:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(35044128767260234)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(35290532168617669)
,p_list_item_display_sequence=>380
,p_list_item_link_text=>unistr('Inactivaci\00F3n Agencia de Viajes ')
,p_list_item_link_target=>'f?p=&APP_ID.:221:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(35044128767260234)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(39976025674518948)
,p_list_item_display_sequence=>481
,p_list_item_link_text=>unistr('Actualizaci\00F3n Contribuyente')
,p_list_item_link_target=>'f?p=&APP_ID.:207:&SESSION.::&DEBUG.:207:P207_TIPO_INSCRIPCION:ANRI:'
,p_parent_list_item_id=>wwv_flow_api.id(35044128767260234)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40240797952025880)
,p_list_item_display_sequence=>491
,p_list_item_link_text=>'Puestos Fronterizos'
,p_list_item_link_target=>'f?p=&APP_ID.:233:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(32537178489739949)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'233,234'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(81566994391576384)
,p_list_item_display_sequence=>701
,p_list_item_link_text=>'Actualizaciones Pendientes'
,p_parent_list_item_id=>wwv_flow_api.id(32537178489739949)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(36577782852044949)
,p_list_item_display_sequence=>431
,p_list_item_link_text=>'Registro o cambio de apoderados'
,p_list_item_link_target=>'f?p=&APP_ID.:231:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(81566994391576384)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'231'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(78938547331414367)
,p_list_item_display_sequence=>691
,p_list_item_link_text=>unistr('Actualizaci\00F3n Representante Legal')
,p_list_item_link_target=>'f?p=&APP_ID.:235:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(81566994391576384)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'235,236'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(81582289545185954)
,p_list_item_display_sequence=>711
,p_list_item_link_text=>unistr('Actualizaci\00F3n Tipo Impuesto')
,p_list_item_link_target=>'f?p=&APP_ID.:237:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(81566994391576384)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'237,238'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(106502000897818659)
,p_list_item_display_sequence=>761
,p_list_item_link_text=>unistr('Activaci\00F3n usuario externo')
,p_list_item_link_target=>'f?p=&APP_ID.:239:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(32537178489739949)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'239'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(13707771333172655)
,p_list_item_display_sequence=>791
,p_list_item_link_text=>'Carga Documentos'
,p_list_item_link_target=>'f?p=&APP_ID.:152:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(32537178489739949)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'152'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(22427047190212232)
,p_list_item_display_sequence=>801
,p_list_item_link_text=>unistr('Env\00EDo de Contrase\00F1as')
,p_list_item_link_target=>'f?p=&APP_ID.:251:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(32537178489739949)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'251'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(13398292903782845)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Reportes'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(23193436703230108)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Reporte Movimientos Contribuyente'
,p_list_item_link_target=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'NEVER'
,p_parent_list_item_id=>wwv_flow_api.id(13398292903782845)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'300'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(23202346546152372)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Reporte Movimientos No Contribuyente'
,p_list_item_link_target=>'f?p=&APP_ID.:301:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'NEVER'
,p_parent_list_item_id=>wwv_flow_api.id(13398292903782845)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'301'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(39363275063179516)
,p_list_item_display_sequence=>451
,p_list_item_link_text=>'Inscripciones por estado'
,p_list_item_link_target=>'f?p=&APP_ID.:302:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(13398292903782845)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'302'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(39708537043628573)
,p_list_item_display_sequence=>452
,p_list_item_link_text=>'Des-inscripciones por estado'
,p_list_item_link_target=>'f?p=&APP_ID.:304:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(13398292903782845)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'304'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(39687394559546777)
,p_list_item_display_sequence=>461
,p_list_item_link_text=>unistr('Envi\00F3 correos usuarios externos')
,p_list_item_link_target=>'f?p=&APP_ID.:303:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(13398292903782845)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'303'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(47070530275756446)
,p_list_item_display_sequence=>681
,p_list_item_link_text=>unistr('Creaci\00F3n de usuarios externos')
,p_list_item_link_target=>'f?p=&APP_ID.:305:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(13398292903782845)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'305'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32005048069370800)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Consultas'
,p_list_item_link_target=>'#'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32005384494384537)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>unistr('Bit\00E1cora par\00E1metros ')
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_api.id(32005048069370800)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32009466200639476)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Venta')
,p_list_item_link_target=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32005384494384537)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'400'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32946868767442168)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Tel\00E9fono')
,p_list_item_link_target=>'f?p=&APP_ID.:401:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32005384494384537)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'401'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33430279131826968)
,p_list_item_display_sequence=>210
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Requisito ')
,p_list_item_link_target=>'f?p=&APP_ID.:402:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32005384494384537)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33950124315098883)
,p_list_item_display_sequence=>260
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Modalidad')
,p_list_item_link_target=>'f?p=&APP_ID.:403:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32005384494384537)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'403'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(34123774988810889)
,p_list_item_display_sequence=>280
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Apoderado')
,p_list_item_link_target=>'f?p=&APP_ID.:404:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32005384494384537)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'404'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(34224763496459666)
,p_list_item_display_sequence=>290
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Identificaci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:405:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32005384494384537)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'405'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(34291673501546034)
,p_list_item_display_sequence=>300
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Puesto Fronterizo')
,p_list_item_link_target=>'f?p=&APP_ID.:406:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32005384494384537)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'406'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(34387387389611379)
,p_list_item_display_sequence=>320
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Contribuyente')
,p_list_item_link_target=>'f?p=&APP_ID.:407:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32005384494384537)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'407'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(34567101053424648)
,p_list_item_display_sequence=>330
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Ente')
,p_list_item_link_target=>'f?p=&APP_ID.:408:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32005384494384537)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(34572513673696681)
,p_list_item_display_sequence=>340
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Local')
,p_list_item_link_target=>'f?p=&APP_ID.:409:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32005384494384537)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'409'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(34732776013177858)
,p_list_item_display_sequence=>350
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Empleado')
,p_list_item_link_target=>'f?p=&APP_ID.:410:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32005384494384537)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'410'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40912479656062807)
,p_list_item_display_sequence=>501
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Correo')
,p_list_item_link_target=>'f?p=&APP_ID.:411:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32005384494384537)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'411'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40938627308190127)
,p_list_item_display_sequence=>511
,p_list_item_link_text=>unistr('Bit\00E1cora encargado correos')
,p_list_item_link_target=>'f?p=&APP_ID.:412:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32005384494384537)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'412'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40958863201306107)
,p_list_item_display_sequence=>521
,p_list_item_link_text=>unistr('Bit\00E1cora tipo solicitud')
,p_list_item_link_target=>'f?p=&APP_ID.:413:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32005384494384537)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'413'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(45545747786470155)
,p_list_item_display_sequence=>671
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Recomendaci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:441:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32005384494384537)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'441'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(98272056199187829)
,p_list_item_display_sequence=>731
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Noticia')
,p_list_item_link_target=>'f?p=&APP_ID.:442:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32005384494384537)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'442'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(98342465050536560)
,p_list_item_display_sequence=>751
,p_list_item_link_text=>unistr('Bit\00E1cora Noticias SIT')
,p_list_item_link_target=>'f?p=&APP_ID.:443:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(32005384494384537)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'443'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40982494944790512)
,p_list_item_display_sequence=>531
,p_list_item_link_text=>unistr('Bit\00E1coras Procesos')
,p_parent_list_item_id=>wwv_flow_api.id(32005048069370800)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40983049250032524)
,p_list_item_display_sequence=>541
,p_list_item_link_text=>unistr('Bit\00E1cora inscripci\00F3n regular')
,p_list_item_link_target=>'f?p=&APP_ID.:414:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(40982494944790512)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'414'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(41122226746113281)
,p_list_item_display_sequence=>542
,p_list_item_link_text=>unistr('Bit\00E1cora Inscripci\00F3n Vuelos Ch\00E1rter')
,p_list_item_link_target=>'f?p=&APP_ID.:416:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(40982494944790512)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'416'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(41128539578128819)
,p_list_item_display_sequence=>543
,p_list_item_link_text=>unistr('Bit\00E1cora Inscripci\00F3n Agencia no recaudadora de impuestos')
,p_list_item_link_target=>'f?p=&APP_ID.:417:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(40982494944790512)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'417'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(41083793171098726)
,p_list_item_display_sequence=>551
,p_list_item_link_text=>unistr('Bit\00E1cora Maestro Contribuyente')
,p_list_item_link_target=>'f?p=&APP_ID.:415:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(40982494944790512)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'415'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(41279321079757035)
,p_list_item_display_sequence=>561
,p_list_item_link_text=>unistr('Bit\00E1cora Hoteles')
,p_list_item_link_target=>'f?p=&APP_ID.:418:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(40982494944790512)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'418'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(41289468585790215)
,p_list_item_display_sequence=>571
,p_list_item_link_text=>unistr('Bit\00E1cora Puesto Fronterizo')
,p_list_item_link_target=>'f?p=&APP_ID.:419:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(40982494944790512)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'419'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(41297796084801637)
,p_list_item_display_sequence=>581
,p_list_item_link_text=>unistr('Bit\00E1cora Ferias Internacionales')
,p_list_item_link_target=>'f?p=&APP_ID.:420:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(40982494944790512)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'420'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(41308397014827597)
,p_list_item_display_sequence=>591
,p_list_item_link_text=>unistr('Bit\00E1cora Funcionarios / Ex Funcionarios')
,p_list_item_link_target=>'f?p=&APP_ID.:421:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(40982494944790512)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'421'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(41317576915868168)
,p_list_item_display_sequence=>601
,p_list_item_link_text=>unistr('Bit\00E1cora Concesiones Golfo de Papagayo')
,p_list_item_link_target=>'f?p=&APP_ID.:422:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(40982494944790512)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'422'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(41326683992924393)
,p_list_item_display_sequence=>611
,p_list_item_link_text=>unistr('Bit\00E1cora Alquileres Propiedades ICT (Locales)')
,p_list_item_link_target=>'f?p=&APP_ID.:423:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(40982494944790512)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'423'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(41335694080935889)
,p_list_item_display_sequence=>621
,p_list_item_link_text=>unistr('Bit\00E1cora Garant\00EDas de cumplimiento')
,p_list_item_link_target=>'f?p=&APP_ID.:424:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(40982494944790512)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'424'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(41344661583950769)
,p_list_item_display_sequence=>631
,p_list_item_link_text=>unistr('Bit\00E1cora Garant\00EDas de participaci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:425:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(40982494944790512)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'425'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(41355192549728879)
,p_list_item_display_sequence=>641
,p_list_item_link_text=>unistr('Bit\00E1cora Otros Entes Externos')
,p_list_item_link_target=>'f?p=&APP_ID.:426:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(40982494944790512)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'426'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(114107514694752016)
,p_list_item_display_sequence=>771
,p_list_item_link_text=>unistr('Bit\00E1cora Comprueba Requisitos')
,p_list_item_link_target=>'f?p=&APP_ID.:444:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(40982494944790512)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'444'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(114707562192657211)
,p_list_item_display_sequence=>781
,p_list_item_link_text=>unistr('Bit\00E1cora Solicitud Des-inscripci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:445:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(40982494944790512)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'445'
);
wwv_flow_api.component_end;
end;
/
